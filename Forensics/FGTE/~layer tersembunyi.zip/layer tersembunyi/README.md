Gambar ini tampak biasa saja…
Tapi apakah benar-benar tidak ada apa-apa di balik warnanya?
Kadang rahasia tersembunyi bukan di atas permukaan, melainkan di “lapisan terdalam” sebuah gambar.

## Solution

Use `stegsolve`'s "Green Plane 0".
