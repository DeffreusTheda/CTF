sebuah dokumen rahasia dari agen intelijen ditemukan.
Sekilas terlihat ada pesan dengan sebagian teks ditutupi kotak hitam (redacted).
.
Namun, apakah kamu yakin pesan itu benar-benar hilang?
Coba analisis isi PDF dengan lebih dalam... mungkin masih ada sesuatu yang tersembunyi.

## Solution

CTRL+A, nanti ada `https://pastebin.com/AY9UniGh`, dan password untuk pastebin itu "adalah `agent rahasia`".
