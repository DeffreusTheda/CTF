Sebuah gambar menyimpan flag dalam dua bagian: bagian pertama disimpan sebagai metadata EXIF, bagian kedua disisipkan langsung ke dalam file gambar.
.
Periksa metadata dulu lalu gunakan alat yang tepat untuk menemukan sisa flag.

## Solution

```
 $ zsteg -n 1 ada_udang_dibalik_batu.png                                                                                                                                                           21:41:31 
[?] 29 bytes of extra data after image end (IEND), offset = 0xb74e0
extradata:0         .. text: "Tools_Strings_For_Forensics}\n"
meta Comment        .. text: "FGTE{Exif_Tools_"
imagedata           .. text: "\t"
```
