#!/bin/sh
while true; do
  > /var/www/storage/logs/app.log
  sleep 60
done
