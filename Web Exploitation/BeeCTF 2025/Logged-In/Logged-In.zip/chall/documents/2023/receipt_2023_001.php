<?php ?>
<h2>Receipt 2023 #001</h2>
<p>Payer: <strong>PT. Demo Jaya</strong></p>
<p>Amount: Rp 1.200.000</p>
<p>Date: 2023-03-12</p>
