<?php ?>
<h2>Invoice 2023 #445</h2>
<p>Client: <strong>PT. PETIR777</strong></p>
<p>Amount Due: Rp 7.500.000</p>
<p>Due Date: 2023-11-25</p>
