<?php ?>
<h2>NPWP Registry (2024)</h2>
<p>Name: <strong>Asep Nusantara</strong></p>
<p>NPWP: 12.345.678.9-012.345</p>
<p>Status: Active</p>
