<?php ?>
<h2>Annual Tax Summary (2024)</h2>
<p>NPWP: 12.345.678.9-012.345</p>
<p>Total Income: Rp 180.000.000</p>
<p>Tax Paid: Rp 13.500.000</p>
