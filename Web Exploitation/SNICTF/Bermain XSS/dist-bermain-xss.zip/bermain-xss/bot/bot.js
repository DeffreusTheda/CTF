const { Builder } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');
const fs = require('fs');
const path = require('path');

const CONFIG = {
    APPNAME: process.env['APPNAME'] || "Admin",
    APPURL: process.env['APPURL'] || "http://172.17.0.1",
    APPURLREGEX: process.env['APPURLREGEX'] || "^.*$",
    APPFLAG: process.env['APPFLAG'] || "fake{flag}",
    APPLIMITTIME: Number(process.env['APPLIMITTIME'] || "60"),
    APPLIMIT: Number(process.env['APPLIMIT'] || "5"),
    APPEXTENSIONS: (() => {
        const extDir = path.join(__dirname, 'extensions');
        return fs.readdirSync(extDir)
                 .filter(file => fs.lstatSync(path.join(extDir, file)).isDirectory())
                 .map(file => path.join(extDir, file))
                 .join(',');
    })(),
    APPBROWSER: process.env['BROWSER'] || 'chromedriver'
};

console.table(CONFIG);

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function getContext() {
    // Use ChromeDriver with Selenium
    const chromedriverPath = '/usr/local/bin/chromedriver';
    const chromiumPath = '/usr/bin/chromium'
    const options = new chrome.Options();
    options.setChromeBinaryPath(chromiumPath);
    options.addArguments(
        '--no-sandbox',
        '--disable-dev-shm-usage',
        '--headless',
        '--disable-gpu',
        '--disable-software-rasterizer',
        '--disable-extensions',
        '--disable-translate',
        '--disable-background-networking',
        '--disable-sync',
        '--metrics-recording-only',
        '--safebrowsing-disable-auto-update',
        '--disable-default-apps',
        '--mute-audio',
        '--no-first-run',
        '--ignore-certificate-errors',
        '--ignore-ssl-errors',
        `--user-data-dir=/tmp/chrome-user-data`
    );
    const driver = new Builder()
        .forBrowser('chrome')
        .setChromeOptions(options)
        .setChromeService(new chrome.ServiceBuilder(chromedriverPath))
        .build();
    console.log("Driver started successfully");

    return driver;
}

async function visitUrl(urlToVisit) {
    const driver = await getContext();

    try {
        // Set a cookie with the flag before visiting the URL
        await driver.get(CONFIG.APPURL);
        await driver.manage().addCookie({ name: "flag", value: CONFIG.APPFLAG });

        // Now visit the specified URL
        await driver.get(urlToVisit);
        console.log(`ChromeDriver visiting ${urlToVisit}`);
        
        await sleep(15000); // Wait to allow page load and potential actions
    } catch (e) {
        console.error("Error visiting URL:", e);
    } finally {
        await driver.quit();
    }
}

console.log("Bot started...");

module.exports = {
    name: CONFIG.APPNAME,
    urlRegex: CONFIG.APPURLREGEX,
    rateLimit: {
        windowS: CONFIG.APPLIMITTIME,
        max: CONFIG.APPLIMIT
    },
    bot: visitUrl
};
