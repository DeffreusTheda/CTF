const express = require("express")
const app = express();
const path = require("path")
const route = express.Router()
const bot = require("./bot")
const rateLimit = require("express-rate-limit")
const dns = require("dns").promises;

app.use(express.urlencoded({ extended: false }))
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
if (process.env.USE_PROXY){
    app.set('trust proxy', () => true)
}

const limit = rateLimit({
    ...bot,
    handler: ((req, res, _next) => {
        const timeRemaining = Math.ceil((req.rateLimit.resetTime - Date.now()) / 1000)
        res.status(429).json({
            error: `Too many requests, please try again later after ${timeRemaining} seconds.`,
        });
    })
})



route.post("/", limit, async (req, res) => {
    const { url } = req.body;
    
    if (!url) {
        return res.status(400).send({ error: "Url is missing." });
    }
    
    if (!RegExp(bot.urlRegex).test(url)) {
        return res.status(422).send({ error: "URL didn't match this regex format " + bot.urlRegex });
    }
    try {
        const parsedUrl = new URL(url);
        const hostname = parsedUrl.hostname;
        const addresses = await dns.resolve(hostname);
        console.log(hostname)
        console.log(addresses)
        if (addresses.includes("127.0.0.1") || addresses.includes("::1")) {
            return res.status(403).send({ error: "Access to localhost URLs is restricted." });
        }
        if (await bot.bot(url)) {
            return res.send({ success: "Admin successfully visited the URL." });
        } else {
            return res.status(500).send({ error: "Admin failed to visit the URL." });
        }
    } catch (err) {
        // Handle invalid URL or DNS resolution errors
        return res.status(400).send({ error: "Invalid URL or could not resolve hostname." });
    }
});


route.get("/", (_, res) => {
    const { name } = bot
    res.render("index", { name });
});

route.get("/test", (_, res) => {
    res.render("test");
});

app.use("/", route)

app.listen(3000, () => {
    console.log("Server running at http://localhost:80");
});
