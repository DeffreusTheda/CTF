

<?php echo e($isAdmin); ?>


<?php echo e($flag); ?><?php /**PATH /app/resources/views/admin.blade.php ENDPATH**/ ?>