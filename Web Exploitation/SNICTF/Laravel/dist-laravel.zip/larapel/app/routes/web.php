<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});
Route::get('/admin', function () {
    $ipIsPublic = filter_var(
        request()->ip(),
        FILTER_VALIDATE_IP,
        FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
    );

    if ($ipIsPublic) {
        return "?";
    }
    return view('admin', ["flag" => env("FLAG", "SNI{ini_real_flag}")]);
});
