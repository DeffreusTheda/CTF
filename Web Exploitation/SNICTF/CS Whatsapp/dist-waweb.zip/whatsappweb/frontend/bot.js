const { chromium } = require('playwright');
const jwt = require('jsonwebtoken');
const generateJwt = () => {
    const secret = process.env.JWT_SECRET;
    if (!secret) {
        throw new Error('JWT_SECRET is not defined in the environment variables.');
    }
    const payload = {
        username: 'bengsky13',
        role: "admin"
    };
    const options = {
        expiresIn: '1h',
    };
    return jwt.sign(payload, secret, options);
};
function sleep(s) {
    return new Promise((resolve) => setTimeout(resolve, s));
}

(async () => {
    const token = generateJwt();
    console.log('Generated JWT:', token);
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    const page = await context.newPage();
    page.on('dialog', async dialog => {
        console.log(`Dialog message: ${dialog.message()}`); // Log the prompt message
        // Fill the dialog based on the message
        if (dialog.type() === 'prompt') {
            await dialog.accept(token);
        } else {
            await dialog.dismiss(); // Dismiss any other dialogs
        }
    });
    await page.goto('http://localhost:3000/');
    while(true){
        await sleep(5000)
        let currentUrl = await page.url();
        console.log(currentUrl)
        if(currentUrl !== "http://localhost:3000/") await page.goto('http://localhost:3000/');
    }
})().catch((error) => {
    console.error('Error:', error);
    process.exit(0);
});
