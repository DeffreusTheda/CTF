const express = require('express');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const app = express();
const path = require('path');
const PORT = 3000;
app.use(cookieParser());
const JWT_SECRET = process.env.JWT_SECRET || 'REDACTED';
const FLAG = process.env.FLAG || 'SNI{fake_flag}';
const authenticateJWT = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ error: 'No token provided' });
    }
    const token = authHeader.split(' ')[1];
    const verified = jwt.verify(token, JWT_SECRET);
    if(verified.username !== "bengsky13") res.status(400).json({ error: 'Invalid token' });
    if(verified.role !== "admin") res.status(400).json({ error: 'Invalid token' });
    req.user = verified;
    next();
  } catch (error) {
    res.status(400).json({ error: 'Invalid token' });
  }
};
const isLocal = (req, res, next) => {
    try {
        let ip = req.ip;
        ip = ip.replace('::ffff:', '');
        console.log(ip)
        if (ip !== '127.0.0.1') {
            return res.status(403).send('Access denied: Only local requests are allowed.');
          }
      next();
    } catch (error) {
      res.status(400).json({ error: 'forbidden' });
    }
  };

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/get_flag', authenticateJWT,isLocal, (req, res) => {
    res.send(FLAG);
});
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

