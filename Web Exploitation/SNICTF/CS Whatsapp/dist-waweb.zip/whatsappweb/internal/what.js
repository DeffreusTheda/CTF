const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const WebSocket = require('ws');
const path = require('path');
const sessionPath = path.join(__dirname, '.wwebjs_auth');
const cachePath = path.join(__dirname, '.wwebjs_cache');
const client = new Client({
    authStrategy: new LocalAuth({
        dataPath: sessionPath,
        cachePath: cachePath
    }),
    puppeteer: {
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    }
});
let blacklist = []
setInterval(() =>{
    blacklist = []
}, 5000)
let ws;
const wss = new WebSocket.Server({ port: 3000 });
wss.on('connection', (wws) => {
    console.log("CONNECTION")
    ws = wws
  });

client.on('message', async message => {
if(message.body.startsWith("[PAYLOAD]")){
    console.log(message.body)
    const found = blacklist.find(element => element === message.from);
    if(found){
    }
    else
    {
        blacklist.push(message.from)
        ws.send(message.body.substr(9))
        console.log('send', message.body.substr(9), 'to', message.from)
    }

}
});
client.on('qr', (qr) => {
    qrcode.generate(qr, { small: true });
});
client.on('ready', () => {
    console.log('Client is ready!');
});
client.initialize();
