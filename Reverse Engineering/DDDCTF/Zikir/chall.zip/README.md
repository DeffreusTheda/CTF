# Zikir

**Category** : Reverse Engineering
**Points** : 456

Bulan Ramadhan adalah bulan penuh berkah, di mana setiap amal ibadah dilipatgandakan pahalanya. Salah satu ibadah yang memiliki keutamaan besar di bulan ini adalah zikir. Dalam surat Al-Ahzab ayat 41-43, Allah SWT berfirman:

"Hai orang-orang yang beriman, berzikirlah (dengan menyebut nama) Allah, zikir yang sebanyak-banyaknya. Dan bertasbihlah kepada-Nya di waktu pagi dan petang. Dialah yang memberi rahmat kepadamu dan malaikat-Nya (memohonkan ampunan untukmu), agar Dia mengeluarkan kamu dari kegelapan kepada cahaya (yang terang). Dan Dia Maha Penyayang kepada orang-orang yang beriman."

Ayat ini menegaskan bahwa zikir bukan sekadar ibadah lisan, tetapi juga jalan menuju cahaya Allah SWT. Dengan memperbanyak zikir di bulan Ramadhan, kita mendapatkan berbagai keutamaan, di antaranya:

Mendapatkan Rahmat dan Ampunan Allah
Allah dan para malaikat-Nya memberikan rahmat dan memohonkan ampunan bagi mereka yang senantiasa berzikir. Di bulan Ramadhan, di mana pintu ampunan terbuka lebar, memperbanyak zikir akan menjadi wasilah untuk mendapatkan pengampunan dari Allah SWT.

Menjadi Lebih Tenang dan Kuat dalam Ibadah
Zikir mengingatkan hati kepada Allah dan menjauhkan kita dari kegelisahan. Ketika kita menghadapi tantangan hidup, dengan berzikir, Allah akan memberi ketenangan dan kemudahan dalam menghadapi segala urusan.

Menghapus Dosa dan Meningkatkan Derajat di Sisi Allah
Rasulullah SAW bersabda:
“Maukah kalian aku beritahu tentang amal yang paling baik, paling suci di sisi Tuhan kalian, paling tinggi derajatnya, lebih baik dari bersedekah emas dan perak, serta lebih baik dari berjihad?”
Para sahabat menjawab, "Tentu, wahai Rasulullah."
Beliau bersabda, "Zikir kepada Allah." (HR. Tirmidzi).

Menjadi Cahaya di Dunia dan Akhirat
Dalam ayat 43 surat Al-Ahzab, Allah menyebutkan bahwa dengan berzikir, kita akan dikeluarkan dari kegelapan menuju cahaya. Artinya, zikir menjadikan hidup kita lebih terarah, penuh keberkahan, dan mendapatkan cahaya petunjuk di dunia maupun akhirat.

Oleh karena itu, marilah kita memperbanyak zikir di bulan Ramadhan, baik dengan membaca tasbih, tahmid, tahlil, takbir, maupun doa dan istighfar. Dengan demikian, kita akan semakin dekat dengan Allah dan meraih keberkahan yang tak terhingga.

"Ya Allah, jadikanlah lisan kami selalu basah dengan mengingat-Mu, dan hati kami selalu tenang dalam naungan rahmat-Mu." 🤲✨

Sebagai siswa RPL, saya membuat sebuah program untuk berzikir. Semoga amal ibadah kita diterima di bulan ramdhan ini.

![WhatsApp_Image_2025-03-14_at_10.49.58.jpeg](/files/143c7a8a1a5bd66a835886c723082fc4/WhatsApp_Image_2025-03-14_at_10.49.58.jpeg)

> Author: P41

## Files : 
 - [zikir.exe](./zikir.exe)


