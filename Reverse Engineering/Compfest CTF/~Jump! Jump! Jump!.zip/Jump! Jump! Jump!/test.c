#include "defs.h"
#include <stdio.h>

__int64 sub_131F(int a1, int a2)
{
  int v2; // eax
  int v3; // eax
  int i; // [rsp+4h] [rbp-14h]
  _BYTE v6[5]; // [rsp+Fh] [rbp-9h]
  int v7; // [rsp+14h] [rbp-4h]

  v7 = 0;
  v6[4] = 0;
  *(_DWORD *)v6 = a1 < 0;
  v2 = a1;
  if ( a1 <= 0 )
    v2 = -a1;
  for ( i = v2; i; i >>= 1 )
  {
    v7 += (i & 1) * (a2 << v6[1]);
    ++*(_DWORD *)&v6[1];
  }
  if ( a1 >= 0 )
    v3 = 1;
  else
    v3 = -1;
  return (unsigned int)(v7 * v3);
}

__int64 ret_1()
{
  return sub_131F(1, 1);
}

__int64 sub_128A(int a1, int a2)
{
  int v5; // [rsp+10h] [rbp-18h]
  int v6; // [rsp+14h] [rbp-14h]
  char v7; // [rsp+18h] [rbp-10h]
  int v8; // [rsp+1Ch] [rbp-Ch]
  __int64 v9; // [rsp+20h] [rbp-8h]

  v9 = 0;
  v8 = 0;
  v7 = 0;
  while ( a1 || a2 )
  {
    v6 = a1 & 1;
    v5 = a2 & 1;
    a1 >>= 1;
    a2 >>= 1;
    v9 += (v8 ^ v5 ^ v6) << v7;
    v8 = v6 & (v8 | v5) | v8 & v5;
    ++v7;
  }
  return ((__int64)v8 << v7) + v9;
}

__int64 sub_13A5()
{
  __int64 v0; // rsi
  int i; // [rsp+8h] [rbp-8h]
  unsigned int v3; // [rsp+Ch] [rbp-4h]

  v3 = ret_1();
  for ( i = 0; i <= 8; ++i )
  {
    v0 = (unsigned int)ret_1();
    v3 = sub_128A(v3, v0);
  }
  return v3;
}

int main() {
  printf("%d\n", (signed int)sub_131F(1, 1));
  printf("%d\n", (signed int)sub_131F(-1, 1));
  printf("%d\n", (signed int)sub_131F(2, 6));
  printf("%d\n", (signed int)sub_13A5(1, 1));
  for (int i = 0; i < 10; ++i)
    printf("%d@%d,2\n", (signed int)sub_128A(i, 2), i);
}
