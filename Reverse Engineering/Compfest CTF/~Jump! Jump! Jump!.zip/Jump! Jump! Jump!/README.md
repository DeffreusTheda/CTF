# Jump! Jump! Jump! Writeup by Deffreus - CompfestCTF 16

###### Author: Maskrio

## Description

a b c d e ?

`nc challenges.ctf.compfest.id 9012`

## Files

[`chall`](https://ctf.compfest.id/files/11457a468e538710b463dbf1f113fc21/chall?token=eyJ1c2VyX2lkIjo3MiwidGVhbV9pZCI6MzA3LCJmaWxlX2lkIjo5MH0.ZtLhHw.iAnRVfpOMmQMA66_FSGQlP73dUo): `Jump! Jump! Jump!/chall: ELF 64-bit LSB pie executable, x86-64, version 1 (SYSV), dynamically linked, interpreter /lib64/ld-linux-x86-64.so.2, BuildID[sha1]=e62434268281e1007b2bfc1c9e1aa6f577397f15, for GNU/Linux 3.2.0, stripped`
