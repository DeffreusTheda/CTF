Binary ini menjalankan kuis 10 soal

## Solution

The function for printing the flag have no dependencies on the answers.
It just decode the flag and prints it.
So we just replicate it, copy pasting from IDA's decompiled code into a C code.
