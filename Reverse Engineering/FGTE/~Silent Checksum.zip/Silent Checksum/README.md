Sebuah berkas diserahkan. Jalankan atau buka, lalu temukan satu jawaban yang benar di dalamnya.

## Solution
