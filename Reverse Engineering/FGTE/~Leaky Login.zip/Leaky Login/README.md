## Solution

Just use `strings`
