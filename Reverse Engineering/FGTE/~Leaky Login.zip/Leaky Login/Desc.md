Sebuah program login sederhana meminta username dan password. Jika kredensial benar, program akan menampilkan flag.
.
Tapi — sesuatu bocor. Coba periksa binary sebelum menjalankannya. Ada petunjuk yang sengaja ditanamkan di dalam program untuk membantu pemain yang mengetahui alat yang tepat.
