

    Author: Archangel (@Ultramilk)

Tahun 2011. Saat itu harga Bitcoin masih sangat murah (setara harga permen).

Sang Admin membeli banyak sekali Bitcoin, tapi pacarnya meninggalkannya karena menganggap dia "halu" dan menghamburkan uang untuk mainan internet yang tidak berguna.

Sakit hati, Admin mengunci semua asetnya di BitSecure Wallet dan bersumpah tidak akan membukanya sampai dia sukses. Sekarang, Bitcoin sudah bernilai miliaran! Tapi masalahnya... dia lupa password-nya karena sudah kelamaan.

Yang dia ingat, password-nya adalah nama kota istimewa tempat dia ditinggal nikah. Bantu Admin membuktikan ke mantannya bahwa dia sekarang sudah jadi "Sultan"!

Hati-hati: Salah password = Saldo zonk & pesan sampah.