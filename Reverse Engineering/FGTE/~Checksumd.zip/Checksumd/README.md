Sebuah tool checksum sederhana dibuat menggunakan Golang untuk memverifikasi integritas sebuah file.

Namun, file data.bin yang seharusnya valid telah dimodifikasi oleh seseorang, sehingga proses verifikasi selalu gagal.
Bisakah kamu memperbaiki isi data.bin agar lolos proses verifikasi checksum?

## Solution

`strings`