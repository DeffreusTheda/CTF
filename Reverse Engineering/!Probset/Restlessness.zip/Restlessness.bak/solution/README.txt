1. unzip
2. open Automator.app
3. 'Open an Existing Document'
4. select the extracted presents
5. 'run' (top right)
6. enter your password; 'run' again if incorrect
7. when done, go to Device Management
8. install the new JAMF profile
9. done! enjoy! ;)
