# Bad Savior - Medium

hey there i got this JAMF patcher for you so that you can freely browse the web freely once again!!! rc'b wxc vjufjan! cadbc vn, hxda yjbbfxamb rb cxcjuuh bjon ;)

part 1: something that listen
part 2: somewhere in vcs
part 3: something about demon
part 4: something that hooks
part 5: something that rules

PS: you don't need macOS to solve this! :p

Hint 1: just ignore public key encryptions. also, be keen for potentially encoded string.
Hint 2: check out the urls the malware is connecting to! look around there!
Hint 3: you'll most likely find the flag parts non-sequentially, that's intended!
