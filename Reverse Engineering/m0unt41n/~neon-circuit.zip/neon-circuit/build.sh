#!/bin/bash

rm -rf dist
npm run build
