###### Brandon

⚠️ WARNING: do not run this! this will actually mess up your system!

## Solution

https://grok.com/share/bGVnYWN5_54379dfd-c753-46c4-b898-65b0cc33ba2d
