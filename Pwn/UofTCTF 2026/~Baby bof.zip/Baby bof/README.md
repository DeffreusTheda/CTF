People said gets is not safe, but I think I figured out how to make it safe.

nc 34.48.173.44 5000

Author: White
