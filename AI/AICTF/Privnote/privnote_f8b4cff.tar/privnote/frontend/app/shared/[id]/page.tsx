'use client'

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import CryptoJS from 'crypto-js'

interface Note {
  id: string
  cypher_text: string
  owner_id: string
  created_at: string
  is_viewed: boolean
}

export default function SharedNotePage() {
  const params = useParams()
  const [note, setNote] = useState<Note | null>(null)
  const [decryptedText, setDecryptedText] = useState<string>('')
  const [error, setError] = useState<string>('')
  const [isLoading, setIsLoading] = useState<boolean>(true)

  useEffect(() => {
    const fetchNote = async () => {
      try {
        const response = await fetch(`/api/notes/${params.id}`)
        if (response.ok) {
          const data = await response.json()
          setNote(data)

          const fragment = window.location.hash.substring(1)
          if (fragment) {
            const decryptedText = decryptNote(data, fragment)
            if (decryptedText) {
              setDecryptedText(decryptedText)
            } else {
              setError('Failed to decrypt note. The key might be invalid.')
            }
          }
        } else if (response.status === 403) {
          setError('This note has already been viewed and cannot be accessed again.')
        } else {
          setError('Failed to fetch note.')
        }
      } catch (error) {
        console.error('Error fetching note:', error)
        setError('An error occurred while fetching the note.')
      } finally {
        setIsLoading(false)
      }
    }

    fetchNote()
  }, [params.id])

  const decryptNote = (note: Note, key: string): string | null => {
    try {
      const bytes = CryptoJS.AES.decrypt(note.cypher_text, key)
      const decryptedText = bytes.toString(CryptoJS.enc.Utf8)
      if (decryptedText) {
        fetch(`/api/notes/${note.id}/change-viewed`, {
          method: 'POST'
        })
        return decryptedText
      }
      return null
    } catch (error) {
      console.error('Decryption failed:', error)
      return null
    }
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 p-8">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-red-500">Error</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-red-500">{error}</p>
              <div className="flex justify-center">
                <Link href="/login">
                  <Button variant="outline">Go to Login</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (isLoading || !note || !decryptedText) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading note...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-2xl mx-auto">
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Shared Note</CardTitle>
          </CardHeader>
          <CardContent className="flex-1 overflow-hidden">
            <div className="max-h-[49vh] overflow-y-auto pr-2 font-mono text-sm">
              <p 
                className="whitespace-pre-wrap break-words leading-relaxed"
                style={{ 
                  wordBreak: 'break-word',
                  overflowWrap: 'break-word'
                }}
              >
                {decryptedText}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
} 