'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import Cookies from 'js-cookie'
import CryptoJS from 'crypto-js'
import { exampleNotes } from './exampleNotes'

interface Note {
  id: string
  title: string
  cypher_text: string
  decryption_key?: string | null
  owner_id: string
  created_at: string
  is_viewed: boolean
  similarity_score?: number
}

export default function NotesPage() {
  const router = useRouter()
  const [notes, setNotes] = useState<Note[]>([])
  const [newNote, setNewNote] = useState('')
  const [newNoteTitle, setNewNoteTitle] = useState('')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [shareDialogOpen, setShareDialogOpen] = useState(false)
  const [selectedNote, setSelectedNote] = useState<Note | null>(null)
  const [isSaving, setIsSaving] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [isSearching, setIsSearching] = useState(false)
  const [searchResults, setSearchResults] = useState<Note[]>([])
  const [hasSearched, setHasSearched] = useState(false)

  useEffect(() => {
    fetchNotes()
  }, [])

  useEffect(() => {
    const updatedNotes = notes.map(note => ({
      ...note,
      decryption_key: localStorage.getItem(`note_key_${note.id}`)
    }))
    setNotes(updatedNotes)
  }, [notes.length])

  const createExampleNotes = async () => {
    for (const note of exampleNotes) {
      const encryptionKey = generateEncryptionKey()
      const encryptedText = CryptoJS.AES.encrypt(note.content, encryptionKey).toString()

      const token = Cookies.get('token')
      if (!token) continue

      const response = await fetch('/api/notes', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title: note.title, cypher_text: encryptedText })
      })

      if (response.ok) {
        const data = await response.json()
        localStorage.setItem(`note_key_${data.id}`, encryptionKey)

        await fetch(`/api/notes/${data.id}/embedding`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            embedding: note.embedding
          })
        })
      }
      fetchNotes()
    }
  }

  useEffect(() => {
    if (localStorage.getItem('shouldCreateExampleNotes') === 'true') {
      createExampleNotes()
      localStorage.removeItem('shouldCreateExampleNotes')
    }
  }, [])

  const fetchNotes = async () => {
    try {
      const token = Cookies.get('token')
      if (!token) {
        router.push('/login')
        return
      }

      const response = await fetch('/api/notes', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setNotes(data)
      } else if (response.status === 401) {
        Cookies.remove('token')
        router.push('/login')
      }
    } catch (error) {
      console.error('Failed to fetch notes:', error)
      Cookies.remove('token')
      router.push('/login')
    }
  }

  const changeViewed = async (note: Note) => {
    try {
        if (!note.is_viewed){
          return
        }
        const token = Cookies.get('token')
        if (!token) {
            router.push('/login')
            return
          }
        const response = await fetch(`/api/notes/${note.id}/change-viewed`, {
            headers: {
              'Authorization': `Bearer ${token}`
            },
            method: 'POST'
          })

        if (response.ok) {
            fetchNotes()
        }
        else if (response.status === 401) {
            router.push('/login')
          }
    } catch (error) {
      console.error('Failed to delete note:', error)
    }
  }

  const generateEncryptionKey = () => {
    return CryptoJS.lib.WordArray.random(16).toString()
  }

  const handleCreateNote = async () => {
    try {
      setIsSaving(true)
      const token = Cookies.get('token')
      if (!token) {
        router.push('/login')
        return
      }

      const encryptionKey = generateEncryptionKey()
      const encryptedText = CryptoJS.AES.encrypt(newNote, encryptionKey).toString()

      const response = await fetch('/api/notes', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title: newNoteTitle, cypher_text: encryptedText })
      })

      if (response.ok) {
        const data = await response.json()
        localStorage.setItem(`note_key_${data.id}`, encryptionKey)

        const embeddingResponse = await fetch('/embedding/embed', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ text: newNote })
        })

        if (embeddingResponse.ok) {
          const embeddingData = await embeddingResponse.json()
          await fetch(`/api/notes/${data.id}/embedding`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              embedding: embeddingData.embedding
            })
          })
        }

        setNewNote('')
        setNewNoteTitle('')
        setIsDialogOpen(false)
        fetchNotes()
      } else if (response.status === 401) {
        router.push('/login')
      }
    } catch (error) {
      console.error('Failed to create note:', error)
    } finally {
      setIsSaving(false)
    }
  }

  const decryptNote = (note: Note): string => {
    try {
      const key = localStorage.getItem(`note_key_${note.id}`)
      if (!key) return 'Decryption key not found'

      const bytes = CryptoJS.AES.decrypt(note.cypher_text, key)
      const decrypted = bytes.toString(CryptoJS.enc.Utf8)
      if (!decrypted) return 'Failed to decrypt note'

      return decrypted
    } catch (error) {
      console.log(error)
      return 'Failed to decrypt note'
    }
  }

  const handleLogout = () => {
    Cookies.remove('token')
    router.push('/login')
  }

  const getShareableLink = (note: Note): string => {
    const key = localStorage.getItem(`note_key_${note.id}`)
    return `${window.location.origin}/shared/${note.id}#${key}`
  }

  const handleDelete = async (note: Note) => {
    try {
      const token = Cookies.get('token')
      if (!token) {
        router.push('/login')
        return
      }

      const response = await fetch(`/api/notes/${note.id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        localStorage.removeItem(`note_key_${note.id}`)
        fetchNotes()
      } else if (response.status === 401) {
        router.push('/login')
      }
    } catch (error) {
      console.error('Failed to delete note:', error)
    }
  }

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      setSearchResults([])
      setHasSearched(false)
      return
    }

    setIsSearching(true)
    setHasSearched(true)
    try {
      const token = Cookies.get('token')
      if (!token) {
        router.push('/login')
        return
      }

      const embedResponse = await fetch('/embedding/embed', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ text: searchQuery })
      })

      if (!embedResponse.ok) {
        console.error('Failed to get embeddings from embedder')
        return
      }

      const embeddingData = await embedResponse.json()

      const searchResponse = await fetch(`/api/search/similar`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ embedding: embeddingData.embedding })
      })

      if (searchResponse.ok) {
        const results = await searchResponse.json()
        setSearchResults(results.filter((note: Note) => note.similarity_score && note.similarity_score > 0.8))
      } else if (searchResponse.status === 401) {
        Cookies.remove('token')
        router.push('/login')
      }
    } catch (error) {
      console.error('Search failed:', error)
    } finally {
      setIsSearching(false)
    }
  }

  const handleClearSearch = () => {
    setSearchQuery('')
    setSearchResults([])
    setHasSearched(false)
  }

  const displayNotes = searchResults.length > 0 ? searchResults : notes

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">My Notes</h1>
        <div className="flex gap-4">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search notes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !isSearching && searchQuery.trim()) {
                  handleSearch()
                }
              }}
              className="w-64 pr-8"
            />
            {searchQuery && !isSearching && (
              <button
                onClick={handleClearSearch}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            )}
            {isSearching && (
              <div className="absolute right-2 top-1/2 transform -translate-y-1/2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-900"></div>
              </div>
            )}
          </div>
          <Button
            variant="outline"
            onClick={handleSearch}
            disabled={isSearching || !searchQuery.trim()}
          >
            Search
          </Button>
          <Button variant="outline" onClick={handleLogout}>Logout</Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>Create Note</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Create a New Note</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <label htmlFor="noteTitle" className="block text-sm font-medium text-gray-700 mb-1">
                    Note Title
                  </label>
                  <Input
                    id="noteTitle"
                    placeholder="Enter note title..."
                    value={newNoteTitle}
                    onChange={(e) => setNewNoteTitle(e.target.value)}
                    className="w-full"
                    title="WARNING: note title is not protected by end-to-end encryption"
                  />
                  <p className="text-xs text-red-500 mt-1">WARNING: note title is not protected by end-to-end encryption</p>
                </div>
                <div>
                  <label htmlFor="noteContent" className="block text-sm font-medium text-gray-700 mb-1">
                    Note Content
                  </label>
                  <Textarea
                    id="noteContent"
                    placeholder="Enter your note..."
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    className="min-h-[210px] font-mono text-sm leading-relaxed resize-none"
                    style={{
                      whiteSpace: 'pre-wrap',
                      wordBreak: 'break-word',
                      overflowWrap: 'break-word'
                    }}
                  />
                </div>
                <Button onClick={handleCreateNote} className="w-full" disabled={isSaving || !newNoteTitle.trim() || !newNote.trim()}>
                  {isSaving ? 'Saving...' : 'Save Note'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {hasSearched && !isSearching && searchResults.length === 0 && (
          <div className="col-span-full text-center text-gray-500 py-8">Nothing found</div>
        )}
        {displayNotes.map((note) => (
          <Card key={note.id} className="w-full">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">
                    {note.title}
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <p className="text-xs text-gray-500 mt-1">ID: {note.id}</p>
                    {note.similarity_score !== undefined && (
                      <span className="text-xs text-blue-500 mt-1">
                        {Math.round(note.similarity_score * 100)}% match
                      </span>
                    )}
                  </div>
                </div>
                {note.is_viewed && (
                  <span className="text-sm text-gray-500">Viewed</span>
                )}
              </div>
            </CardHeader>
            <CardContent className="h-[210px] overflow-y-auto">
              <p className="text-sm text-gray-600 break-words whitespace-pre-wrap">
                {decryptNote(note)}
              </p>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setSelectedNote(note)
                  setShareDialogOpen(true)
                  changeViewed(note).then(() => {})
                }}
              >
                {'Share'}
              </Button>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => handleDelete(note)}
              >
                Delete
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Share Note</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
              <div>
                <p className="text-sm text-gray-500 mb-2">Share this link to access the note:</p>
                <div className="flex items-center space-x-2">
                  <Input
                    readOnly
                    value={selectedNote ? getShareableLink(selectedNote) : ''}
                    onClick={(e) => (e.target as HTMLInputElement).select()}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      if (selectedNote) {
                        navigator.clipboard.writeText(getShareableLink(selectedNote))
                      }
                    }}
                  >
                    Copy
                  </Button>
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  The decryption key is included in the link. Anyone with this link can view the note.
                  <br />
                  <strong>Note:</strong> The note can only be viewed once through the shared link.
                </p>
              </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
} 