from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from openai import OpenAI
from dotenv import load_dotenv
import os
from datetime import datetime

import schemas

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
MODEL = "text-embedding-ada-002"

app = FastAPI(title="embedder", docs_url=None, redoc_url=None, openapi_url=None)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def healthcheck():
    return {"status": "ok", "timestamp": datetime.now().isoformat()}

@app.post("/embed")
def create_embedding(text_input: schemas.TextToEmbed):
    try:
        response = client.embeddings.create(
            model=MODEL,
            input=text_input.text
        )
        embedding_vector = response.data[0].embedding

        return {
            "text": text_input.text,
            "embedding": embedding_vector,
            "model": MODEL
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong")

