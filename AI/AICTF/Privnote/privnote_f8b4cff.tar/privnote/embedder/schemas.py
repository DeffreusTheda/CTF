from pydantic import BaseModel
from datetime import datetime
from typing import List

class TextToEmbed(BaseModel):
    text: str

class EmbeddingCreate(BaseModel):
    text: str
    embedding: List[float]
    model: str

class Embedding(EmbeddingCreate):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True 