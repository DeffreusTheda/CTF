from sqlalchemy import create_engine, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv
import os

load_dotenv()

POSTGRES_USER = os.getenv("POSTGRES_USER")
POSTGRES_PASSWORD = os.getenv("POSTGRES_PASSWORD")
POSTGRES_HOST = os.getenv("POSTGRES_HOST")
POSTGRES_PORT = os.getenv("POSTGRES_PORT")
POSTGRES_DB = os.getenv("POSTGRES_DB")

SQLALCHEMY_DATABASE_URL = f"postgresql://{POSTGRES_USER}:{POSTGRES_PASSWORD}@{POSTGRES_HOST}:{POSTGRES_PORT}/{POSTGRES_DB}"

engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

READONLY_POSTGRES_USER = os.getenv("READONLY_POSTGRES_USER")
READONLY_POSTGRES_PASSWORD = os.getenv("READONLY_POSTGRES_PASSWORD")

READONLY_SQLALCHEMY_DATABASE_URL = f"postgresql://{READONLY_POSTGRES_USER}:{READONLY_POSTGRES_PASSWORD}@{POSTGRES_HOST}:{POSTGRES_PORT}/{POSTGRES_DB}"
readonly_engine = create_engine(READONLY_SQLALCHEMY_DATABASE_URL)
readonly_SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
readonly_Base = declarative_base()

def get_readonly_db():
    db = readonly_SessionLocal()
    try:
        yield db
    finally:
        db.close()