from datetime import datetime
from uuid import UUID
from typing import List, Optional, Any
from pydantic import BaseModel, EmailStr

class UserBase(BaseModel):
    username: str
    email: EmailStr

class UserCreate(UserBase):
    password: str

class User(UserBase):
    id: UUID

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: str | None = None

class NoteBase(BaseModel):
    title: str
    cypher_text: str

class NoteCreate(NoteBase):
    pass

class NoteUpdate(BaseModel):
    embedding: List[float]

class Note(NoteBase):
    id: str
    owner_id: UUID
    is_viewed: bool
    created_at: datetime
    embedding: Optional[List[float]] = None

    class Config:
        from_attributes = True

class EmbeddingBase(BaseModel):
    embedding: List[Any]

class EmbeddingCreate(EmbeddingBase):
    pass

class Embedding(EmbeddingBase):
    id: UUID
    owner_id: UUID
    created_at: datetime

    class Config:
        from_attributes = True