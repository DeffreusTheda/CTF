from datetime import datetime
import uuid
import secrets
import string
from pgvector.sqlalchemy import Vector
from sqlalchemy import Column, String, DateTime, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID
from database import Base

def generate_note_id():
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(16))

class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)


class Note(Base):
    __tablename__ = "notes"

    id = Column(String(16), primary_key=True, default=generate_note_id)
    title = Column(String)
    cypher_text = Column(String)
    owner_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    is_viewed = Column(Boolean, default=False)
    is_deleted = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    embedding = Column(Vector(1536), nullable=True)