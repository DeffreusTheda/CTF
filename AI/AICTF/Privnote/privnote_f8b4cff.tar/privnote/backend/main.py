import math
from datetime import datetime
from typing import Annotated, List
from fastapi import FastAPI, Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import text
import models
import schemas
import auth
from database import engine, get_db, get_readonly_db

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="backend", docs_url=None, redoc_url=None, openapi_url=None)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def healthcheck():
    return {"status": "ok", "timestamp": datetime.now().isoformat()}

@app.post("/register", response_model=schemas.Token)
def register(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = auth.get_user(db, username=user.username)
    if db_user:
        raise HTTPException(
            status_code=400,
            detail="Username already registered"
        )

    hashed_password = auth.get_password_hash(user.password)
    db_user = models.User(
        username=user.username,
        email=user.email,
        hashed_password=hashed_password
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    access_token = auth.create_access_token(data={"sub": db_user.username})
    return {"access_token": access_token, "token_type": "bearer"}


@app.post("/token", response_model=schemas.Token)
async def login(
        form_data: Annotated[OAuth2PasswordRequestForm, Depends()],
        db: Session = Depends(get_db)
):
    user = auth.authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = auth.create_access_token(data={"sub": user.username})
    return {"access_token": access_token, "token_type": "bearer"}


@app.get("/users/me", response_model=schemas.User)
async def read_users_me(
        current_user: Annotated[models.User, Depends(auth.get_current_user)]
):
    return current_user


@app.post("/notes", response_model=schemas.Note)
def create_note(note: schemas.NoteCreate, current_user: Annotated[models.User, Depends(auth.get_current_user)],
                db: Session = Depends(get_db)):
    try:
        db_note = models.Note(
            title=note.title,
            cypher_text=note.cypher_text,
            created_at=datetime.utcnow(),
            owner_id=current_user.id,
            is_viewed=False,
            is_deleted=False
        )
        db.add(db_note)
        db.commit()

        db.refresh(db_note)
        return db_note
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong")


@app.get("/notes", response_model=List[schemas.Note])
def read_notes(current_user: Annotated[models.User, Depends(auth.get_current_user)],
                db: Session = Depends(get_db)):
    try:
        db_notes = db.query(models.Note).filter(
            models.Note.owner_id == current_user.id,
            models.Note.is_deleted == False
        ).order_by(models.Note.created_at.desc()).all()
        return db_notes
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong")


@app.get("/notes/{note_id}", response_model=schemas.Note)
def read_note(note_id: str, shared: bool = True, db: Session = Depends(get_db)):
    db_note = db.query(models.Note).filter(models.Note.id == note_id).first()
    if not db_note:
        raise HTTPException(status_code=404, detail="Note not found")

    if db_note.is_viewed and shared:
        raise HTTPException(status_code=403, detail="This note has already been viewed and cannot be accessed via shared link")

    return db_note


@app.post("/notes/{note_id}/change-viewed", response_model=schemas.Note)
def mark_note_viewed(note_id: str, db: Session = Depends(get_db)):
    db_note = db.query(models.Note).filter(models.Note.id == note_id).first()
    if not db_note:
        raise HTTPException(status_code=404, detail="Note not found")

    db_note.is_viewed = not db_note.is_viewed
    db.commit()
    db.refresh(db_note)
    return db_note


@app.delete("/notes/{note_id}", response_model=schemas.Note)
def delete_note(note_id: str, current_user: Annotated[models.User, Depends(auth.get_current_user)],
                db: Session = Depends(get_db)):
    try:
        db_note = db.query(models.Note).filter(
            models.Note.id == note_id,
            models.Note.owner_id == current_user.id,
            models.Note.is_deleted == False
        ).first()
        
        if not db_note:
            raise HTTPException(status_code=404, detail="Note not found")

        db_note.is_deleted = True
        db.commit()
        db.refresh(db_note)
        return db_note
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong")


@app.post("/notes/{note_id}/embedding", response_model=schemas.Note)
def update_note_embedding(note_id: str, embedding: schemas.NoteUpdate, current_user: Annotated[models.User, Depends(auth.get_current_user)], db: Session = Depends(get_db)):
    try:
        db_note = db.query(models.Note).filter(
            models.Note.id == note_id,
            models.Note.owner_id == current_user.id,
            models.Note.is_deleted == False
        ).first()
        
        if not db_note:
            raise HTTPException(status_code=404, detail="Note not found")

        if len(embedding.embedding) != 1536:
            raise HTTPException(status_code=400, detail="Invalid embedding dimensions. Expected 1536 dimensions.")

        db_note.embedding = embedding.embedding
        db.commit()
        db.refresh(db_note)
        return db_note
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong")


@app.post("/search/similar")
async def search_similar(request: Request, current_user: Annotated[models.User, Depends(auth.get_current_user)], db: Session = Depends(get_readonly_db)):
    try:
        request_data = await request.json()
        embedding = request_data.get('embedding', [])
        
        query = f"""SELECT id, title, cypher_text, created_at, is_viewed, embedding, embedding <=> '{embedding}' AS distance FROM notes WHERE owner_id = '{current_user.id}' AND is_deleted = false AND embedding IS NOT NULL ORDER BY distance"""

        result = db.execute(text(query))

        similar_notes = []
        for row in result:
            note_dict = {
                "id": row.id,
                "title": row.title,
                "cypher_text": row.cypher_text,
                "created_at": row.created_at,
                "is_viewed": row.is_viewed,
                "embedding": row.embedding,
                "similarity_score": (1 - row.distance if row.distance is not None and not math.isnan(row.distance) else 0.0)
            }
            similar_notes.append(note_dict)

        return similar_notes
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


