import os
import uuid
import torch
import logging
from fastapi import FastAPI, UploadFile, File, Form, Request, HTTPException, Response
from fastapi.responses import HTMLResponse, RedirectResponse, FileResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import psycopg2
from psycopg2 import sql
from PIL import Image
import io
from starlette.middleware.sessions import SessionMiddleware
from starlette.responses import Response
import secrets

app = FastAPI(docs_url=None, redoc_url=None)

templates = Jinja2Templates(directory="templates")

app.mount("/thumbnails", StaticFiles(directory="thumbnails"), name="thumbnails")
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

DB_CONFIG = {
    'dbname': 'cat_catalogue',
    'user': 'postgres',
    'password': 'postgres',
    'host': 'db',
    'port': '5432'
}

UPLOAD_FOLDER = 'uploads'
THUMBNAIL_FOLDER = 'thumbnails'
ALLOWED_EXTENSIONS = {'pth.tar', 'pt', 'tar'}

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
if not os.path.exists(THUMBNAIL_FOLDER):
    os.makedirs(THUMBNAIL_FOLDER)

app.add_middleware(SessionMiddleware, secret_key=os.environ.get('SESSION_SECRET', secrets.token_hex(32)))

def get_db_connection():
    return psycopg2.connect(**DB_CONFIG)

def init_db():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS models (
            id SERIAL PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            model_path TEXT NOT NULL,
            thumbnail_path TEXT NOT NULL,
            upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            public BOOLEAN DEFAULT FALSE,
            session_id TEXT NOT NULL,
            layer_count INTEGER DEFAULT 0
        )
    ''')
    conn.commit()
    cur.close()
    conn.close()

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    response = Response()
    session_id = get_or_create_session_id(request, response)
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT id, name, description, model_path, thumbnail_path, upload_date, public, session_id, layer_count FROM models ORDER BY upload_date DESC')
    all_models = cur.fetchall()
    cur.close()
    conn.close()
    # Filter models: show public or private owned by this session
    models = [m for m in all_models if m[6] or m[7] == session_id]
    return templates.TemplateResponse("index.html", {"request": request, "models": models})

@app.get("/upload", response_class=HTMLResponse)
async def upload_get(request: Request):
    return templates.TemplateResponse("upload.html", {"request": request})

@app.post("/upload")
async def upload_post(
    request: Request,
    model: UploadFile = File(...),
    thumbnail: UploadFile = File(None),
    name: str = Form(...),
    description: str = Form(...),
    public: str = Form(None),
):
    logger.info("Received upload request")
    response = Response()
    session_id = get_or_create_session_id(request, response)

    forbidden_words = ["dog", "pup", "puppy", "hound", "canine"]
    if any(word in name.lower() or word in description.lower() for word in forbidden_words):
        logger.warning("Forbidden word detected in name or description")
        return templates.TemplateResponse(
            "upload.html",
            {"request": request, "error": "Dog-related models are not allowed."}
        )

    if not model.filename:
        logger.warning("Empty model filename")
        return templates.TemplateResponse(
            "upload.html", 
            {"request": request, "error": "No selected model file"}
        )
        
    if model and allowed_file(model.filename):
        logger.info(f"Processing model file: {model.filename}")
        model_filename = str(uuid.uuid4()) + os.path.splitext(model.filename)[1]
        model_path = os.path.join(UPLOAD_FOLDER, model_filename)
        
        model_content = await model.read()
        with open(model_path, "wb") as f:
            f.write(model_content)
        logger.info(f"Model saved to {model_path}")
        
        try:
            loaded_model = torch.load(model_path, map_location='cpu')
            logger.info("Model loaded and verified successfully")
            import torch.nn as nn
            def count_layers(module):
                if isinstance(module, dict):
                    return len(module.keys())
                
                layer_count = 0
                if isinstance(module, nn.Module):
                    for name, child in module.named_children():
                        layer_count += 1
                return layer_count
                
            layer_count = 0
            if isinstance(loaded_model, dict):
                layer_count = count_layers(loaded_model)
            elif hasattr(loaded_model, 'state_dict'):
                layer_count = count_layers(loaded_model.state_dict())
            elif hasattr(loaded_model, 'module'):
                layer_count = count_layers(loaded_model.module)
            elif isinstance(loaded_model, nn.Module):
                layer_count = count_layers(loaded_model)
            
            if layer_count == 0:
                raise ValueError("Model has no layers")
        except Exception as e:
            logger.error(f"Error loading model: {str(e)}")
            os.remove(model_path)
            return templates.TemplateResponse(
                "upload.html", 
                {"request": request, "error": "Invalid PyTorch model"}
            )
            
        thumbnail_filename = 'placeholder.png'
        thumbnail_path = os.path.join(THUMBNAIL_FOLDER, thumbnail_filename)
        
        if thumbnail and thumbnail.filename:
            logger.info(f"Processing thumbnail: {thumbnail.filename}")
            thumbnail_filename = str(uuid.uuid4()) + '.jpg'
            thumbnail_path = os.path.join(THUMBNAIL_FOLDER, thumbnail_filename)
            try:
                thumbnail_content = await thumbnail.read()
                img = Image.open(io.BytesIO(thumbnail_content))
                img.thumbnail((300, 300))
                img.save(thumbnail_path)
                logger.info(f"Thumbnail saved to {thumbnail_path}")
            except Exception as e:
                logger.error(f"Error saving thumbnail: {str(e)}")
                os.remove(model_path)
                return templates.TemplateResponse(
                    "upload.html", 
                    {"request": request, "error": "Invalid image file"}
                )
        else:
            logger.info("No thumbnail provided, using placeholder")
            
        try:
            conn = get_db_connection()
            cur = conn.cursor()
            is_public = bool(public)
            cur.execute(
                'INSERT INTO models (name, description, model_path, thumbnail_path, public, session_id, layer_count) VALUES (%s, %s, %s, %s, %s, %s, %s)',
                (name, description, model_filename, thumbnail_filename, is_public, session_id, layer_count)
            )
            conn.commit()
            cur.close()
            conn.close()
            logger.info("Model record created in database successfully")
        except Exception as e:
            logger.error(f"Database error: {str(e)}")
            os.remove(model_path)
            if thumbnail and thumbnail.filename:
                os.remove(thumbnail_path)
            return templates.TemplateResponse(
                "upload.html", 
                {"request": request, "error": "Database error"}
            )
            
        logger.info("Upload process completed successfully")
        return RedirectResponse(url="/", status_code=303)

@app.get("/download/{filename}")
async def download_model(filename: str):
    return FileResponse(
        path=os.path.join(UPLOAD_FOLDER, filename), 
        filename=filename,
        media_type='application/octet-stream'
    )

@app.on_event("startup")
async def startup_event():
    init_db()

def get_or_create_session_id(request: Request, response: Response):
    session_id = request.session.get('session_id')
    if not session_id:
        session_id = str(uuid.uuid4())
        request.session['session_id'] = session_id
    return session_id

if __name__ == '__main__':
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=5000, reload=True) 
