

    Author: aria

temukan flag yang tersembunyi di file zip terenkripsi.
Password zip tidak terlalu rumit

## Solution

>`zip2john secret.zip >hash.txt`
>`john --wordlist=~/Downloads/rockyou.txt hash.txt`
>password is iloveyou
>flag.txt is decoy
>`git log`
>`git reset --hard <init commit>`
