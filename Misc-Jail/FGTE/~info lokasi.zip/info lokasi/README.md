

    Author: yunx1ao

aku menemukan sebuah file misterius yang berisikan angka angka koordinat. katanya angka angka itu bisa menghasilkan sesuatu yang penting. apakah itu?

## Solution

negate the x coordinates
the plot in desmos graphing