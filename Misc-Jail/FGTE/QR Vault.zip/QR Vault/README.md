## Solution

```
 $ echo 'UEsDBAoAAAAAANwRO1uub+7rIgAAACIAAAAIABwAZmxhZy50eHRVVAkAA6BI12igSNdodXgLAAEE6AMAAAToAwAARkdURXtaaXBCYXNlNjRfUVJfQ2hhbGxlbmdlXzIwMjV9ClBLAQIeAwoAAAAAANwRO1uub+7rIgAAACIAAAAIABgAAAAAAAEAAAD/gQAAAABmbGFnLnR4dFVUBQADoEjXaHV4CwABBOgDAAAE6AMAAFBLBQYAAAAAAQABAE4AAABkAAAAAAA=' | base64 -d
PK
�;[�o��"flag.txtUT	�H�h�H�hux
                                  ��FGTE{ZipBase64_QR_Challenge_2025}
PK
�;[�o��"��flag.txtUT�H�hux
                          ��PKNd%                
```
