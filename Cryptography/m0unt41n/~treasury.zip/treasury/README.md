data and time uses the same decryption, but only data is checked if it's flag.
just swap them.
