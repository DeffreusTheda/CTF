basically, the sign function is the same as the decryption function, but without dec's secret type validation
